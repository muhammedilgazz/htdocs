<?php

namespace App\Controllers;

class PrivacyController {
    public function index() {
        require_once 'C:/xampp/htdocs/views/privacy/index.php';
    }
}