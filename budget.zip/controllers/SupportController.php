<?php

namespace App\Controllers;

class SupportController {
    public function index() {
        require_once 'C:/xampp/htdocs/views/support/index.php';
    }
}