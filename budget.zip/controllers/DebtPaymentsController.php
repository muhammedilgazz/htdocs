<?php
class DebtPaymentsController {
    public function index() {
        require_once __DIR__ . '/../views/debt_payments/index.php';
    }
} 