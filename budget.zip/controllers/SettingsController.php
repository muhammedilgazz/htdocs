<?php

namespace App\Controllers;

class SettingsController {
    public function index() {
        require_once 'C:/xampp/htdocs/views/settings/index.php';
    }
}