<?php
require_once 'C:/xampp/htdocs/config/config.php';
require_once 'C:/xampp/htdocs/models/AccountCredential.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'])) {
    $account_credential_model = new AccountCredential();
    
    $id = (int)$_POST['id'];
    $data = [
        'platform_name' => sanitize_input($_POST['platform_name']),
        'username' => sanitize_input($_POST['username']),
        'password_hash' => password_hash(sanitize_input($_POST['password_hash']), PASSWORD_DEFAULT),
        'login_url' => sanitize_input($_POST['login_url']) ?? null,
        'account_type_id' => (int)$_POST['account_type_id']
    ];

    if ($account_credential_model->update($id, $data)) {
        json_response(['success' => true, 'message' => 'Hesap bilgisi başarıyla güncellendi.']);
    } else {
        json_response(['success' => false, 'message' => 'Hesap bilgisi güncellenirken bir hata oluştu.'], 500);
    }
} else {
    json_response(['success' => false, 'message' => 'Geçersiz istek.'], 400);
}
