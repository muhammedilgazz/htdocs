$('#circle1').circleProgress({
    value: 0.75,
    size: 100,
    thickness: 7,
    lineCap: 'round',
    fill: { color: '#1652F0' },
})
$('#circle2').circleProgress({
    value: 0.75,
    size: 100,
    thickness: 7,
    lineCap: 'round',
    fill: { color: '#1652F0' },
})
$('#circle3').circleProgress({
    value: 0.75,
    size: 100,
    thickness: 7,
    lineCap: 'round',
    fill: { color: '#1652F0' },
})
$('#circle4').circleProgress({
    value: 0.75,
    size: 100,
    thickness: 7,
    lineCap: 'round',
    fill: { color: '#1652F0' },
})



$('#circle5').circleProgress({
    value: 0.75,
    size: 50,
    thickness: 4,
    lineCap: 'round',
    fill: { color: '#51BB25' },
})
$('#circle6').circleProgress({
    value: 0.75,
    size: 50,
    thickness: 4,
    lineCap: 'round',
    fill: { color: '#51BB25' },
})
$('#circle7').circleProgress({
    value: 0.75,
    size: 50,
    thickness: 4,
    lineCap: 'round',
    fill: { color: '#51BB25' },
})
$('#circle8').circleProgress({
    value: 0.75,
    size: 50,
    thickness: 4,
    lineCap: 'round',
    fill: { color: '#51BB25' },
})
