<div class="footer">
    <div class="footer-inner">
        <div class="footer-left">
            <span>2025 <a href="#">Ekash</a> | All Rights Reserved Xtreme AI | Her Hakkı Saklıdır.</span>
        </div>
        <div class="footer-right">
            <a href="#" class="footer-social-btn"><i class="material-icons-round">facebook</i></a>
            <a href="#" class="footer-social-btn"><i class="material-icons-round">link</i></a>
            <a href="#" class="footer-social-btn"></a>
            <a href="#" class="footer-social-btn"></a>
        </div>
    </div>
</div>