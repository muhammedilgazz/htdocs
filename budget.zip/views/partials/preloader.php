<!-- Preloader devre dışı bırakıldı - tıklama sorunlarına neden oluyordu -->
<!-- 
<div id="preloader" class="position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center" style="background: rgba(255, 255, 255, 0.9); z-index: 9999; transition: opacity 0.3s ease;">
    <div class="text-center">
        <div class="spinner-border text-primary mb-3" role="status" style="width: 3rem; height: 3rem;">
            <span class="visually-hidden">Yükleniyor...</span>
        </div>
        <h5 class="text-muted">Yükleniyor...</h5>
    </div>
</div>
-->

<script>
    // Preloader tamamen devre dışı
    console.log('Preloader devre dışı bırakıldı');
</script>